clear 
clc 
%define matrix V
V = [11,5,3,2,-18,4,-5,5,-66];

%define vec2
vec2 = V(V>=0)

%define vec1
vec1 = vecFunc(V)


