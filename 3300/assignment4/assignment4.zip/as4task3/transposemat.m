%This function recieves matrix and returns a 3x3 matrix y
function [y] = transposemat(x)
y = [x(1),x(2),x(3);x(4),x(5),x(6);x(7),x(8),x(9)];
end


