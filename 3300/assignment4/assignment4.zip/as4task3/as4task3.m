clear
clc

%enter input matrix x
x = input('What is x?: ');
%call function
y = transposemat(x);
%display matrix y
disp(y);

